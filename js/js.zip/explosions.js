// Explosions, impacts and smoke. One system for every kind of blast:
//   gun      a cannon round striking metal: sparks and a flash
//   puff     a thin smoke puff, used for a burning engine
//   missile  a missile warhead: fireball, shock ring, debris, smoke, and
//            secondary blasts as fuel and stores cook off
//   aircraft a destroyed airframe: a large fireball, wreck debris, a black
//            column, and a run of secondary explosions
//   vehicle  a destroyed tank or truck: a fireball, debris and smoke
//   bomb     a free-fall or guided bomb: a crater of dirt, a larger
//            fireball and shock ring, and a heavy smoke column
// Effects are built from several layers (flash, fireball, ring, debris,
// smoke, sparks) and each one ages on its own clock. Debris lands on the
// terrain and bounces. The whole system is cleared between flights.
import * as THREE from 'three';

const MAX_EFFECTS = 48;
const TYPES = {
  gun:      { fire: 1.2, flash: 0.9, life: 0.35, debris: 0,  smoke: 0,  shock: 0,   sparks: 14, secondary: 0, dirt: 0 },
  puff:     { fire: 0.4, flash: 0,   life: 3.0,  debris: 0,  smoke: 6,  shock: 0,   sparks: 0,  secondary: 0, dirt: 0 },
  missile:  { fire: 9,   flash: 1.6, life: 1.8,  debris: 14, smoke: 22, shock: 22,  sparks: 30, secondary: 2, dirt: 0 },
  aircraft: { fire: 22,  flash: 2.6, life: 4.5,  debris: 40, smoke: 46, shock: 52,  sparks: 60, secondary: 6, dirt: 0 },
  vehicle:  { fire: 8,   flash: 1.6, life: 3.2,  debris: 14, smoke: 26, shock: 0,   sparks: 20, secondary: 3, dirt: 0 },
  bomb:     { fire: 26,  flash: 3.0, life: 4.0,  debris: 60, smoke: 70, shock: 110, sparks: 80, secondary: 3, dirt: 60 },
};
const FIRE_COLORS = [0xfff4c2, 0xffc24a, 0xff7a2a, 0xb5361a, 0x3a2a24];

let scene = null;
let terrainRef = null;
const effects = [];
const timers = [];          // { at, fn }
let puffTex = null;
let clock = 0;

const rnd = (a, b) => a + Math.random() * (b - a);

function softTexture() {
  if (puffTex) return puffTex;
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d');
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.5, 'rgba(255,255,255,0.45)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd; g.fillRect(0, 0, 64, 64);
  puffTex = new THREE.CanvasTexture(c);
  return puffTex;
}

export function initExplosions(s) { scene = s; }

// Terrain height function, handed in each frame by ai.update.
export function setExplosionTerrain(t) { terrainRef = t; }

// Sets off an effect at a world point. kind is one of TYPES. scale multiplies
// its size (1 is a typical missile warhead).
export function boom(kind, at, scale = 1) {
  if (!scene) return;
  const T = TYPES[kind] || TYPES.missile;
  const pos = new THREE.Vector3(at.x, at.y, at.z);
  if (effects.length >= MAX_EFFECTS) disposeEffect(effects.shift());
  const group = new THREE.Group();
  group.position.copy(pos);
  group.userData.heat = 1;
  scene.add(group);
  const e = { kind, T, scale, group, age: 0, life: T.life * (0.85 + Math.random() * 0.3) * Math.sqrt(scale), parts: [], pos };
  const fire = T.fire * scale;

  // flash: a white-hot core that goes out fast
  if (T.flash) {
    const m = new THREE.Mesh(new THREE.SphereGeometry(fire * 0.55, 14, 10),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
    group.add(m); e.parts.push({ type: 'flash', mesh: m, peak: T.flash * scale });
  }

  // fireball: layered spheres, hot inside and dark outside, that rise and cool
  const layers = T.fire ? 5 : 0;
  for (let i = 0; i < layers; i++) {
    const col = FIRE_COLORS[Math.min(FIRE_COLORS.length - 1, i)];
    const m = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 9),
      new THREE.MeshBasicMaterial({ color: col, transparent: true, opacity: 0.95, depthWrite: false }));
    m.position.set(rnd(-0.2, 0.2) * fire, rnd(0, 0.3) * fire, rnd(-0.2, 0.2) * fire);
    group.add(m);
    e.parts.push({ type: 'fire', mesh: m, r: fire * (0.55 + i * 0.12) * rnd(0.85, 1.1), delay: i * 0.03, rise: fire * 0.35 });
  }

  // shock ring: flat on the ground, or a shell in the air
  if (T.shock) {
    const m = new THREE.Mesh(new THREE.RingGeometry(0.9, 1, 48),
      new THREE.MeshBasicMaterial({ color: 0xffe6b0, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, depthWrite: false }));
    m.rotation.x = -Math.PI / 2;
    group.add(m);
    e.parts.push({ type: 'ring', mesh: m, r: T.shock * scale });
  }

  // debris: pieces of the airframe, vehicle or store, thrown outward, falling and bouncing
  for (let i = 0; i < T.debris * Math.min(scale, 2); i++) {
    const hot = Math.random() < 0.4;
    const m = new THREE.Mesh(new THREE.BoxGeometry(rnd(0.12, 0.5), rnd(0.08, 0.3), rnd(0.12, 0.6)),
      new THREE.MeshStandardMaterial({ color: hot ? 0x3a2a20 : 0x25272b, emissive: hot ? 0xff5a1a : 0x000000, emissiveIntensity: hot ? 0.8 : 0, roughness: 0.8, metalness: 0.4 }));
    m.position.set(0, fire * 0.2, 0);
    const a = Math.random() * Math.PI * 2, s = rnd(10, 36) * Math.sqrt(scale);
    const v = new THREE.Vector3(Math.cos(a) * s, rnd(8, 24) * Math.sqrt(scale), Math.sin(a) * s);
    m.rotation.set(rnd(0, 6), rnd(0, 6), rnd(0, 6));
    group.add(m);
    e.parts.push({ type: 'debris', mesh: m, v, spin: new THREE.Vector3(rnd(-8, 8), rnd(-8, 8), rnd(-8, 8)), ground: false, bounces: 0 });
  }

  // smoke: a column of soft puffs that rises and spreads
  if (T.smoke) {
    const n = Math.round(T.smoke * Math.min(scale, 2.5));
    const geo = new THREE.BufferGeometry();
    const P = new Float32Array(n * 3), V = new Float32Array(n * 3), A = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      P[i * 3] = rnd(-0.3, 0.3) * fire; P[i * 3 + 1] = rnd(0, 0.4) * fire; P[i * 3 + 2] = rnd(-0.3, 0.3) * fire;
      V[i * 3] = rnd(-3, 3); V[i * 3 + 1] = rnd(4, 9); V[i * 3 + 2] = rnd(-3, 3);
      A[i] = rnd(0, 0.6);
    }
    geo.setAttribute('position', new THREE.BufferAttribute(P, 3));
    const mat = new THREE.PointsMaterial({ map: softTexture(), color: 0x3d3a38, size: fire * 1.2, sizeAttenuation: true, transparent: true, opacity: 0.7, depthWrite: false });
    const pts = new THREE.Points(geo, mat);
    group.add(pts);
    e.parts.push({ type: 'smoke', pts, P, V, A, n, size: fire * 1.2 });
  }

  // sparks: fast, bright, short-lived streaks
  if (T.sparks) {
    const n = Math.round(T.sparks * Math.min(scale, 2));
    const geo = new THREE.BufferGeometry();
    const P = new Float32Array(n * 3), V = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = rnd(6, 30) * Math.sqrt(scale);
      V[i * 3] = Math.cos(a) * s; V[i * 3 + 1] = rnd(2, 14) * Math.sqrt(scale); V[i * 3 + 2] = Math.sin(a) * s;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(P, 3));
    const mat = new THREE.PointsMaterial({ color: 0xffb35a, size: 0.35 * Math.sqrt(scale), sizeAttenuation: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
    const pts = new THREE.Points(geo, mat);
    group.add(pts);
    e.parts.push({ type: 'sparks', pts, P, V, n, life: T.life * 0.5 });
  }

  // dirt: a dome of earth that falls back for a bomb hitting the ground
  if (T.dirt) {
    const n = T.dirt;
    const geo = new THREE.BufferGeometry();
    const P = new Float32Array(n * 3), V = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = rnd(4, 22) * Math.sqrt(scale);
      V[i * 3] = Math.cos(a) * s; V[i * 3 + 1] = rnd(12, 34) * Math.sqrt(scale); V[i * 3 + 2] = Math.sin(a) * s;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(P, 3));
    const mat = new THREE.PointsMaterial({ color: 0x6b5a46, size: 1.6, sizeAttenuation: true, transparent: true, opacity: 0.9, depthWrite: false });
    const pts = new THREE.Points(geo, mat);
    group.add(pts);
    e.parts.push({ type: 'dirt', pts, P, V, n });
  }

  effects.push(e);

  // secondary blasts: a fuel or store cooking off a little after the first
  for (let i = 0; i < T.secondary; i++) {
    const at2 = rnd(0.15, 1.6) * Math.sqrt(scale);
    const sub = kind === 'aircraft' ? 'missile' : 'gun';
    timers.push({ at: clock + at2, fn: () => boom(sub, { x: pos.x + rnd(-6, 6) * scale, y: pos.y + rnd(0, 4), z: pos.z + rnd(-6, 6) * scale }, 0.7) });
  }
  return e;
}

function disposeEffect(e) {
  if (!e) return;
  if (e.group.parent) e.group.parent.remove(e.group);
  e.group.traverse((o) => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) o.material.dispose();
  });
}

// Advance every effect. Call once per frame.
export function tickExplosions(dt, terrain) {
  if (terrain) terrainRef = terrain;
  clock += dt;
  for (let i = timers.length - 1; i >= 0; i--) {
    if (clock >= timers[i].at) { const t = timers[i]; timers.splice(i, 1); t.fn(); }
  }
  for (const e of effects) {
    e.age += dt;
    const k = Math.min(1, e.age / e.life);
    for (const p of e.parts) stepPart(p, e, dt, k);
  }
  for (let i = effects.length - 1; i >= 0; i--) {
    if (effects[i].age >= effects[i].life) { disposeEffect(effects[i]); effects.splice(i, 1); }
  }
}

function groundAt(x, z) { return terrainRef ? terrainRef.heightAt(x, z) : -1e9; }

function stepPart(p, e, dt, k) {
  const fire = e.T.fire * e.scale;
  if (p.type === 'flash') {
    const f = Math.max(0, 1 - k * 4);
    p.mesh.material.opacity = f; p.mesh.scale.setScalar(1 + k * 1.5);
    return;
  }
  if (p.type === 'fire') {
    const t = Math.max(0, e.age - p.delay);
    const grow = Math.min(1, t / (e.life * 0.25));
    const fade = Math.max(0, 1 - Math.max(0, (k - 0.35)) / 0.65);
    p.mesh.scale.setScalar(Math.max(0.01, p.r * (0.3 + 0.7 * grow)));
    p.mesh.position.y = p.rise * Math.min(1, k * 1.6);
    p.mesh.material.opacity = 0.95 * fade;
    return;
  }
  if (p.type === 'ring') {
    const f = Math.min(1, e.age / (e.life * 0.45));
    p.mesh.scale.setScalar(Math.max(0.01, p.r * f));
    p.mesh.material.opacity = 0.6 * (1 - k);
    return;
  }
  if (p.type === 'debris') {
    if (!p.ground) {
      p.v.y -= 9.8 * dt;
      p.mesh.position.addScaledVector(p.v, dt);
      p.mesh.rotation.x += p.spin.x * dt; p.mesh.rotation.y += p.spin.y * dt; p.mesh.rotation.z += p.spin.z * dt;
      const gy = groundAt(e.pos.x + p.mesh.position.x, e.pos.z + p.mesh.position.z) - e.pos.y;
      if (p.mesh.position.y < gy) {
        p.mesh.position.y = gy;
        if (p.bounces < 2 && p.v.y < -2) { p.v.y = -p.v.y * 0.35; p.v.x *= 0.5; p.v.z *= 0.5; p.bounces++; }
        else { p.v.set(0, 0, 0); p.ground = true; }
      }
    }
    if (p.mesh.material.emissiveIntensity) p.mesh.material.emissiveIntensity = Math.max(0, 0.8 * (1 - k * 2));
    return;
  }
  if (p.type === 'smoke') {
    const { P, V, A, n } = p;
    for (let i = 0; i < n; i++) {
      P[i * 3] += V[i * 3] * dt; P[i * 3 + 1] += V[i * 3 + 1] * dt; P[i * 3 + 2] += V[i * 3 + 2] * dt;
      V[i * 3] *= 1 - 0.3 * dt; V[i * 3 + 2] *= 1 - 0.3 * dt;
    }
    p.pts.geometry.attributes.position.needsUpdate = true;
    p.pts.material.size = p.size * (0.6 + 1.6 * k);
    p.pts.material.opacity = 0.7 * Math.max(0, 1 - k) * Math.min(1, k * 5);
    return;
  }
  if (p.type === 'sparks') {
    const { P, V, n } = p;
    for (let i = 0; i < n; i++) {
      V[i * 3 + 1] -= 18 * dt;
      P[i * 3] += V[i * 3] * dt; P[i * 3 + 1] += V[i * 3 + 1] * dt; P[i * 3 + 2] += V[i * 3 + 2] * dt;
    }
    p.pts.geometry.attributes.position.needsUpdate = true;
    p.pts.material.opacity = Math.max(0, 1 - e.age / p.life);
    return;
  }
  if (p.type === 'dirt') {
    const { P, V, n } = p;
    for (let i = 0; i < n; i++) {
      V[i * 3 + 1] -= 14 * dt;
      P[i * 3] += V[i * 3] * dt; P[i * 3 + 1] += V[i * 3 + 1] * dt; P[i * 3 + 2] += V[i * 3 + 2] * dt;
      V[i * 3] *= 1 - 0.8 * dt; V[i * 3 + 2] *= 1 - 0.8 * dt;
    }
    p.pts.geometry.attributes.position.needsUpdate = true;
    p.pts.material.opacity = 0.9 * Math.max(0, 1 - k * 1.3);
  }
}

// Origin rebase: effects move with the world.
export function shiftExplosions(dx, dz) {
  for (const e of effects) { e.group.position.x -= dx; e.group.position.z -= dz; e.pos.x -= dx; e.pos.z -= dz; }
}

export function clearExplosions() {
  while (effects.length) disposeEffect(effects.pop());
  timers.length = 0;
}
