// Fighter stores (missiles, bombs) and each fighter's hard-point loadout.
//
// A fighter's custom.hardpoints is a list of PAIRS (one per wing station, both
// sides mirrored automatically):
//   { name, at: [x, y, z] (airframe units, +z = starboard), allow: [store ids], load: store id }
// Only the stores listed in `allow` can be loaded on that station, so each jet
// carries only what it is equipped with. Choices are kept per aircraft in this
// browser (localStorage), and a small panel on the picker sets them.
const DEG = Math.PI / 180;
const RADAR = { seeker: 'radar', range: 40000, gate: 45 * DEG, vLaunch: 260, vMax: 900, accel: 110, burn: 9, drag: 0.06, turn: 2.2, maxAge: 40, maxG: 15, gimbal: 60 * DEG, losRate: 30 * DEG };
const IR = { seeker: 'ir', range: 18000, gate: 25 * DEG, vLaunch: 260, vMax: 620, accel: 100, burn: 5, drag: 0.2, turn: 2.8, maxAge: 30, maxG: 25, gimbal: 40 * DEG, losRate: 45 * DEG };
const BOMB = { kind: 'bomb', range: 0, vLaunch: 0 };

const def = (id, label, len, extra) => Object.assign({ id, label, name: label, len, model: `assets/weapons/loadout/${id}.glb` }, extra);
export const STORES = {
  aim9:    def('aim9', 'AIM-9 Sidewinder (fox-2)', 2.91, { kind: 'missile', ...IR }),
  ty90:    def('ty90', 'TY-90 (fox-2)', 1.93, { kind: 'missile', ...IR, range: 15000 }),
  aim7:    def('aim7', 'AIM-7 Sparrow (fox-1)', 3.72, { kind: 'missile', ...RADAR }),
  r77:     def('r77', 'R-77 (fox-3)', 3.58, { kind: 'missile', ...RADAR }),
  r27:     def('r27', 'R-27 (fox-1)', 3.0, { kind: 'missile', ...RADAR, range: 30000 }),
  r27_b:   def('r27_b', 'R-27 variant (fox-1)', 4.14, { kind: 'missile', ...RADAR, range: 30000 }),
  pl11:    def('pl11', 'PL-11 (fox-1)', 3.96, { kind: 'missile', ...RADAR }),
  pl11_b:  def('pl11_b', 'PL-11 variant (fox-1)', 4.02, { kind: 'missile', ...RADAR }),
  jdam:    def('jdam', 'JDAM', 3.97, { ...BOMB }),
  gbu12:   def('gbu12', 'GBU-12 Paveway II', 3.38, { ...BOMB }),
  kab500l: def('kab500l', 'KAB-500L', 3.10, { ...BOMB }),
  agm65:   def('agm65', 'AGM-65 Maverick', 2.48, { ...BOMB }),
  hellfire:def('hellfire', 'AGM-114 Hellfire', 1.64, { ...BOMB }),
  kh29:    def('kh29', 'Kh-29', 3.99, { ...BOMB }),
};
// Every store GLB is in metres with the nose on +X.
export function storeUrl(id) { return STORES[id].model; }

export function getLoadout(spec) {
  const hp = spec && spec.custom && spec.custom.hardpoints;
  if (!hp) return null;
  let saved = null;
  try { saved = JSON.parse(localStorage.getItem('loadout:' + spec.id)); } catch { /* storage blocked */ }
  return hp.map((p, i) => {
    if (Array.isArray(saved) && saved.length === hp.length) {
      const v = saved[i];
      if (v === null || (typeof v === 'string' && p.allow.includes(v))) return v;
    }
    return p.load || null;
  });
}

export function setLoadout(spec, arr) {
  try { localStorage.setItem('loadout:' + spec.id, JSON.stringify(arr)); } catch { /* ignore */ }
}

// Picker panel: one dropdown per station, shown only while choosing a fighter.
export function initLoadoutPanel(getSpec, isPicking) {
  const box = document.createElement('div');
  box.id = 'loadout-panel';
  box.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:50;background:rgba(8,13,24,.88);color:#cfe3f5;font:12px system-ui,sans-serif;padding:8px 10px;border:1px solid #2a3a55;border-radius:6px;display:none;min-width:240px';
  document.body.appendChild(box);
  let shown = null;
  const build = (spec) => {
    box.innerHTML = '';
    const h = document.createElement('div');
    h.textContent = 'LOADOUT: ' + spec.name;
    h.style.cssText = 'font-weight:bold;margin-bottom:6px';
    box.appendChild(h);
    const cur = getLoadout(spec);
    spec.custom.hardpoints.forEach((p, i) => {
      const row = document.createElement('label');
      row.style.cssText = 'display:flex;justify-content:space-between;align-items:center;gap:8px;margin:4px 0';
      row.textContent = p.name;
      const sel = document.createElement('select');
      for (const o of [null, ...p.allow]) {
        const op = document.createElement('option');
        op.value = o === null ? '' : o;
        op.textContent = o === null ? 'empty' : STORES[o].label;
        if ((cur[i] || '') === op.value) op.selected = true;
        sel.appendChild(op);
      }
      sel.onchange = () => { const arr = getLoadout(spec); arr[i] = sel.value || null; setLoadout(spec, arr); };
      row.appendChild(sel);
      box.appendChild(row);
    });
  };
  setInterval(() => {
    const spec = getSpec();
    const show = !!(spec && spec.custom && spec.custom.hardpoints && isPicking());
    box.style.display = show ? 'block' : 'none';
    if (show && spec.id !== shown) { shown = spec.id; build(spec); }
  }, 300);
}
