// Street lights, from the map's road network.
//
// The building tiles already carry the OpenMapTiles "transportation" layer. Its
// road centrelines are sampled every few tens of metres, with the spacing set by
// road class (a motorway has lamps further apart than a side street). Each lamp
// is an additive point of sodium light that is only drawn after dark.
//
// Lamps are stored relative to their tile's corner, like the buildings, so an
// origin shift only moves each tile's group.
import * as THREE from 'three';
import { mercToWorld, origin } from './geo.js?v=20261016172514';

// metres between lamps, by OpenMapTiles road class. Anything else gets none.
const SPACING = { motorway: 60, trunk: 55, primary: 45, secondary: 40, tertiary: 35, minor: 32 };
const LAMP_HEIGHT = 9;          // metres above the ground
const MAX_PER_TILE = 1500;

const VERT = `
uniform float uNight;
uniform float uScale;
varying float vI;
void main() {
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  float d = max(-mv.z, 1.0);
  // a lamp is a few metres across, drawn at its real apparent size, never tiny
  // bigger than before, and a floor of 3.5 px so distant lamps still read
  gl_PointSize = clamp(uScale * 6.0 / d, 3.5, 60.0);
  vI = uNight;
  gl_Position = projectionMatrix * mv;
}`;

const FRAG = `
uniform vec3 uColor;
varying float vI;
void main() {
  float d = length(gl_PointCoord - vec2(0.5));
  float core = smoothstep(0.5, 0.0, d);
  float halo = exp(-d * d * 12.0) * 0.8;         // the glow around the lamp
  float a = min(1.0, (core + halo) * vI * 1.3);
  if (a < 0.01) discard;
  gl_FragColor = vec4(uColor * (core * 2.4 + halo), a);
}`;

export class StreetLights {
  constructor(scene, terrain) {
    this.scene = scene;
    this.terrain = terrain;
    this.tiles = new Map();     // tile key -> { points, cw }
    this.night = 0;
    this.mat = new THREE.ShaderMaterial({
      uniforms: {
        uNight: { value: 0 },
        uScale: { value: 900 },
        uColor: { value: new THREE.Color(0xffb35c) },   // sodium
      },
      vertexShader: VERT,
      fragmentShader: FRAG,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
  }

  // roads: the tile's centrelines, in tile units; cornerMx/My: the tile corner
  ingest(tileKey, roads, cornerMx, cornerMy, tileMerc) {
    this.drop(tileKey);
    const cw = mercToWorld(cornerMx, cornerMy);
    const sizeW = tileMerc * origin.k;
    const out = [];
    for (const f of roads) {
      const cls = String(f.props.class || '');
      const spacing = SPACING[cls];
      if (!spacing) continue;
      if (f.props.brunnel === 'tunnel' || f.props.brunnel === 'bridge') continue;
      for (const ring of f.rings) {
        if (ring.length < 2) continue;
        const scale = sizeW / f.extent;
        this._sample(ring.map(([px, py]) => [px * scale, py * scale]), spacing, cw, out);
        if (out.length >= MAX_PER_TILE) break;
      }
      if (out.length >= MAX_PER_TILE) break;
    }
    if (!out.length) return;
    const pos = new Float32Array(out.length * 3);
    for (let i = 0; i < out.length; i++) {
      pos[i * 3] = out[i][0]; pos[i * 3 + 1] = out[i][1]; pos[i * 3 + 2] = out[i][2];
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const points = new THREE.Points(geo, this.mat);
    points.frustumCulled = false;
    points.position.set(cw.x, 0, cw.z);
    points.visible = this.night > 0.01;
    this.scene.add(points);
    this.tiles.set(tileKey, { points, mx: cornerMx, my: cornerMy });
  }

  // Walk a polyline and place a lamp every `spacing` metres. Positions are
  // stored relative to the tile corner; height comes from the terrain.
  _sample(pts, spacing, cw, out) {
    let carry = spacing / 2;      // first lamp half a spacing in, not on a junction
    for (let i = 0; i < pts.length - 1; i++) {
      const [ax, az] = pts[i], [bx, bz] = pts[i + 1];
      const len = Math.hypot(bx - ax, bz - az);
      let d = carry;
      while (d <= len) {
        const t = d / len;
        const x = ax + (bx - ax) * t, z = az + (bz - az) * t;
        const gh = this.terrain.heightAt(cw.x + x, cw.z + z);
        out.push([x, gh + LAMP_HEIGHT, z]);
        if (out.length >= MAX_PER_TILE) return;
        d += spacing;
      }
      carry = d - len;
    }
  }

  drop(tileKey) {
    const e = this.tiles.get(tileKey);
    if (!e) return;
    this.scene.remove(e.points);
    e.points.geometry.dispose();
    this.tiles.delete(tileKey);
  }

  // 0 = day (no lamps), 1 = full night. Lamps fade in through dusk.
  setNight(f) {
    this.night = Math.max(0, Math.min(1, (f - 0.3) / 0.6));
    this.mat.uniforms.uNight.value = this.night;
    for (const e of this.tiles.values()) e.points.visible = this.night > 0.01;
  }

  // Lamp size depends on the screen's pixel height
  update() {
    const pix = window.innerHeight * Math.min(2, window.devicePixelRatio || 1);
    this.mat.uniforms.uScale.value = pix / (2 * Math.tan(31 * Math.PI / 180));
  }

  // The world origin moved: each tile's position comes from its Mercator corner
  onOriginShift() {
    for (const e of this.tiles.values()) {
      const w = mercToWorld(e.mx, e.my);
      e.points.position.set(w.x, 0, w.z);
    }
  }
}
